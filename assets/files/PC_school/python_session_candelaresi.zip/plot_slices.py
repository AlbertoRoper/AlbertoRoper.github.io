# Import all the necessary libraries.

import matplotlib.pyplot as plt
import pencil as pc

# Read the slice files.
# This might require the compilation and execution of src/read_all_videofiles.x.
slices = pc.read.slices()

# Read the grid for the extent of the domain.
grid = pc.read.grid()

# Plot one of the slices.
plt.imshow(slices.xy.uu1[0, :, :].T, origin='lower',
           extent=[grid.x[0], grid.x[-1], grid.y[0], grid.y[-1]])

# Add axix lables'
plt.xlabel(r'$x$')
plt.ylabel(r'$y$')

# Add a colorbar.
cb = plt.colorbar()
cb.set_label(r'$u_x$')

# Save it in a file.
plt.savefig('uu1_xy_t0.pdf')
