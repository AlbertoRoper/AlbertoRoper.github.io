# Import all the necessary libraries.

import matplotlib.pyplot as plt
import pencil as pc

# Read the data cube (var file).
var = pc.read.var(magic='bb', trimall=True)

# Read the grid for the extent of the domain.
grid = pc.read.grid()

# Compute the magnetic helicity density.
ab = pc.math.dot(var.aa, var.bb)

# Plot a slice of the magnetic helicity density.
plt.imshow(ab[16, :, :].T,
           extent=[grid.x[0], grid.x[-1], grid.y[0], grid.y[-1]])

# Add axix lables'
plt.xlabel(r'$x$')
plt.ylabel(r'$y$')

# Add a colorbar.
cb = plt.colorbar()
cb.set_label(r'$H_{\rm mag}$')

# Save it in a file.
plt.savefig('hmag_xy.pdf')
